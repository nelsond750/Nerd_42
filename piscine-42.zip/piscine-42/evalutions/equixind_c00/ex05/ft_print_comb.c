/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: equixind <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/17 19:37:31 by equixind          #+#    #+#             */
/*   Updated: 2024/10/23 16:55:39 by equixind         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_pattern(char first_num, char sec_num, char third_num)
{
	write(1, &first_num, 1);
	write(1, &sec_num, 1);
	write(1, &third_num, 1);
	if (first_num == 55 && sec_num == 56 && third_num == 57)
		write(1, ".\n", 2);
	else
		write(1, ", ", 2);
}

void	ft_print_comb(void)
{
	char	first_num;
	char	sec_num;
	char	third_num;

	first_num = 48;
	while (first_num <= 55)
	{
		sec_num = first_num + 1;
		while (sec_num <= 56)
		{
			third_num = sec_num + 1;
			while (third_num <= 57)
			{
				print_pattern(first_num, sec_num, third_num);
				third_num++;
			}
			sec_num++;
		}
		first_num++;
	}
}
