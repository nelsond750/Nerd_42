#!/bin/sh

FT_NBR1='?"\"'
FT_NBR2='rcrdmddd'

base_convert() {
    local num=$1
    local from_base=$2
    local to_base=$3
    decimal=$(echo "obase=10; ibase=${#from_base}; ${num//?/$(( $(expr index "$from_base" '?') - 1 ))}" | bc)
    result=""
    while [ $decimal -gt 0 ]; do
        digit=$(( decimal % ${#to_base} ))
        result="${to_base:digit:1}$result"
        decimal=$(( decimal / ${#to_base} ))
    done
    echo "$result"
}

sum=$(base_convert "$FT_NBR1" '\"?!' 'gtaio luSnemf')
sum2=$(base_convert "$FT_NBR2" 'mrdoc' 'gtaio luSnemf')
result=$(echo "$sum + $sum2" | bc)
final_result=$(base_convert "$result" 'gtaio luSnemf' 'gtaio luSnemf')

echo "A soma é:"
echo "$final_result"
