/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cgarcia3 <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/20 13:58:43 by cgarcia3          #+#    #+#             */
/*   Updated: 2024/10/20 14:03:26 by cgarcia3         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_numbes(int value, int in, int size_elevado)
{
	char	v;

	if (in < size_elevado)
	{
		write(1, "0", 1);
	}
	while (value != 0)
	{
		v = (value % 10) + 48;
		write(1, &v, 1);
		value /= 10;
	}
}

int	elevado(int n, int elevado)
{
	int	value;
	int	index;

	value = 1;
	if (n != 0)
	{
		index = 1;
		while (index <= elevado)
		{
			value *= n;
			index++;
		}
	}
	else
	{
		return (0);
	}
	return (value);
}

int	print(int status, int in, int size_elevado)
{
	int	number_inverso;
	int	value_anterior;
	int	value;
	int	n;

	number_inverso = 0;
	value_anterior = 10;
	n = in;
	while (n != 0)
	{
		number_inverso *= 10;
		value = (n % 10);
		number_inverso += value;
		n /= 10;
		if (value >= value_anterior)
		{
			return (-1);
		}
		value_anterior = value;
	}
	print_numbes(number_inverso, in, size_elevado);
	return (status);
}

void	function(int n)
{
	int	in;
	int	size_elevado;
	int	size_max;
	int	verificar;

	in = 12345678 / elevado(10, 9 - n);
	size_elevado = elevado(10, n - 1);
	size_max = size_elevado * 9;
	while (in <= size_max)
	{
		if (print(1, in, size_elevado) == 1)
		{
			verificar = in / size_elevado;
			if (verificar == (10 - n))
			{
				in = sizeMax + 1;
			}
			else
			{
				write(1, ", ", 2);
			}
		}
		in++;
	}
}

void	ft_print_combn(int n)
{
	if ((n <= 9) && (n >= 1))
	{
		function(n);
	}
}
