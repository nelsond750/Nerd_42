/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aluis <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/30 16:03:46 by aluis             #+#    #+#             */
/*   Updated: 2024/10/30 21:06:39 by aluis            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find);

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (to_find[i] == '\0')
		return (str);
	while ((to_find[i] != '\0') && (str[j] != '\0'))
	{
		if (to_find[i] == str[j])
		{
			i ++;
			j ++;
		}
		else if (to_find[0] == str[j])
			i = 0;
		else
		{
			i = 0;
			j ++;
		}
	}
	if (to_find[i] == '\0')
		return (&str[j - i]);
	return (NULL);
}
