/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aluis <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/30 21:10:58 by aluis             #+#    #+#             */
/*   Updated: 2024/10/31 03:55:51 by aluis            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size);

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	while (dest[i] != '\0')
		i ++;
	while ((src[j] != '\0') && (i < size - 1))
	{
		dest[i] = src[j];
		j ++;
		i ++;
	}
	while (src[j] != '\0')
	{
		i ++;
		j ++;
	}
	if (i == j)
		return (j);
	dest[i] = '\0';
	return (i);
}
