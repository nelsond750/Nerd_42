/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: edmmateu <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/23 18:44:39 by edmmateu          #+#    #+#             */
/*   Updated: 2024/10/23 19:08:43 by edmmateu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	diff;

	i = 0;
	while (i < size)
	{
		if (tab[i] < tab[size - i -1])
		{
			diff = tab[i];
			tab[i] = tab[size - i - 1];
			tab[size - i - 1];
		}
		i++;
	}
}
