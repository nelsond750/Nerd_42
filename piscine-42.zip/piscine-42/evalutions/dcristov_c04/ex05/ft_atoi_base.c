/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dcristov <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/30 12:49:35 by dcristov          #+#    #+#             */
/*   Updated: 2024/10/30 12:49:53 by dcristov         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	verificar_base(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i])
	{
		if (base[i] == '+' || base[i] == '-' || base[i] <= ' ')
			return (0);
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (i > 1);
}

int	char_to_value(char c, char *base)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (base[i] == c)
			return (i);
		i++;
	}
	return (-1);
}

int	processar_sinal(char **str)
{
	int	sinal;

	sinal = 1;
	while (**str == '+' || **str == '-')
	{
		if (**str == '-')
			sinal = -sinal;
		(*str)++;
	}
	return (sinal);
}

int	ft_atoi_base(char *str, char *base)
{
	int	sinal;
	int	resultado;
	int	valor;
	int	tamanho_base;

	tamanho_base = verificar_base(base);
	if (tamanho_base <= 1)
		return (0);
	while (*str <= ' ')
		str++;
	sinal = processar_sinal(&str);
	resultado = 0;
	valor = char_to_value(*str, base);
	while (valor != -1)
	{
		resultado = resultado * tamanho_base + valor;
		str++;
		valor = char_to_value(*str, base);
	}
	return (resultado * sinal);
}
