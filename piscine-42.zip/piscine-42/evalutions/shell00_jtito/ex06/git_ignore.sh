git ls-files -i -o --exclude-standard
