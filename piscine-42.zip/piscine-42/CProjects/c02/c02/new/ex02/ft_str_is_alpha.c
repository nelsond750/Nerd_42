/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/30 17:49:16 by psimao            #+#    #+#             */
/*   Updated: 2024/10/30 18:42:09 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

int	ft_is_upercase(char c)
{
	return (c >= 'A' && c <= 'Z');
}

int	ft_is_lowercase(char c)
{
	return (c >= 'a' && c <= 'z');
}

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	if (str[0] == '\0')
	{
		return (1);
	}
	while (str[i] != '\0')
	{
		if (ft_is_lowercase(str[i]) || ft_is_upercase(str[i]))
			i++;
		else
			return (0);
	}
	return (1);
}
/*
#include<stdio.h>

int	main(void)
{
	char	*str;

	str = "*&^%%%$";
	printf("Saida: %d", ft_str_is_alpha(str));
}*/
