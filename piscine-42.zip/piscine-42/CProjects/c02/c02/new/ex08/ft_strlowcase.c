/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/30 20:31:13 by psimao            #+#    #+#             */
/*   Updated: 2024/10/30 20:37:27 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str)
{
	char	*original;

	original = str;
	while (*str)
	{
		if (*str >= 'A' && *str <= 'Z')
			*str += 32;
		str++;
	}
	return (original);
}
/*
#include <stdio.h>

int main() {
    char str[] = "Hello, World!";
    printf("Original: %s\n", str);
    printf("Lowcase: %s\n", ft_strlowcase(str));
    return 0;
}*/
