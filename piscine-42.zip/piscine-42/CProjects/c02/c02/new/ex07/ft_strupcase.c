/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/30 19:58:22 by psimao            #+#    #+#             */
/*   Updated: 2024/10/30 20:30:01 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strupcase(char *str)
{
	char	*original;

	original = str;
	while (*str)
	{
		if (*str >= 'a' && *str <= 'z')
			*str -= 32;
		str++;
	}
	return (original);
}
/*
#include <stdio.h>

int main() {
    char str[] = "Hello, World!";
    printf("Original: %s\n", str);
    printf("Uppercase: %s\n", ft_strupcase(str));
    return 0;
}
*/
