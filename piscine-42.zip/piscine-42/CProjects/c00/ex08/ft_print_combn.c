/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/19 04:27:52 by psimao            #+#    #+#             */
/*   Updated: 2024/10/19 04:55:49 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_combn_f(void)
{
	ft_putchar(',');
	ft_putchar(' ');
}

void	ft_print_combination(int *tab, int n)
{
	int	i;
	int	flag;

	flag = 1;
	i = 0;
	while (i < n)
	{
		if (i > 0 && tab[i - 1] >= tab[i])
		{
			flag = 0;
		}
		i++;
	}
	if (flag)
	{
		i = 0;
		while (i < n)
		{
			ft_putchar(tab[i++] + '0');
		}
		if (tab[0] < (10 - n))
		{
			ft_combn_f();
		}
	}
}

void	ft_print_combn(int n)
{
	int	tab[10];
	int	i;

	if (n <= 0 || n >= 10)
		return ;
	i = 0;
	while (i < n)
	{
		tab[i++] = 0;
	}
	while (tab[0] <= (10 - n) && n >= 1)
	{
		ft_print_combination(tab, n);
		tab[n - 1]++;
		i = n;
		while (i && n > 1)
		{
			i--;
			if (tab[i] > 9)
			{
				tab[i - 1]++;
				tab[i] = 0;
			}
		}
	}
}
