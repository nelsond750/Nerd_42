/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_say_tri2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/03 18:53:34 by psimao            #+#    #+#             */
/*   Updated: 2024/11/03 18:53:39 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/ft_rush.h"

int	ft_tn(char *nbr)
{
	return ((ft_strl(nbr) - 1) / 3);
}

int	ft_tp(char *nbr)
{
	return ((ft_strl(nbr) - 1) % 3);
}

char	*ft_slice_tri(char *nbr)
{
	int		i;
	int		end;
	char	*tri;

	end = ft_tp(nbr) + 1;
	tri = malloc(end + 1);
	i = 0;
	while (i < end)
	{
		tri[i] = *nbr;
		i++;
		nbr++;
	}
	tri[i] = 0;
	return (tri);
}
