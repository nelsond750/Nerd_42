/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/03 18:54:32 by psimao            #+#    #+#             */
/*   Updated: 2024/11/03 18:54:43 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/ft_rush.h"

int	main(int argc, char **argv)
{
	char	*dic;
	int		i;
	int		res;

	dic = DICNAME;
	if (argc == 3)
		dic = argv[1];
	if (argc <= 1 || argc > 3)
	{
		ft_putstr("Error\n");
		return (0);
	}
	if (argc == 2)
		res = ft_say_arg(dic, argv[1]);
	i = 2;
	while (i < argc)
	{
		res = ft_say_arg(dic, argv[i]);
		i++;
		if (res == -2)
			return (res);
	}
	return (res);
}
