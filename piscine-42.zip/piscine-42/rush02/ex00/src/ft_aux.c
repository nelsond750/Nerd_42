/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_aux.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/03 18:42:17 by psimao            #+#    #+#             */
/*   Updated: 2024/11/03 18:42:24 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/ft_rush.h"

int	check_atoi(char *str, int i)
{
	if (str[i] < '0' || str[i] > '9')
		return (0);
	while (str[i] != '\0')
	{
		if (str[i] < '0' || str[i] > '9')
		{
			if (str[i] == '.' && str[i + 1] >= '0' && str[i + 1] <= '9')
				return (0);
			str[i] = '\0';
			return (1);
		}
		else
			i++;
	}
	return (1);
}

int	ft_isdigit(char c)
{
	if (c >= '0' && c <= '9')
		return (1);
	return (0);
}

int	ft_isspace(char c)
{
	if (c == 32)
		return (1);
	return (0);
}

int	ft_isnumber(char *str)
{
	int	i;
	int	n;

	while (*str == ' ' || (*str >= 9 && *str <= 13))
		str++;
	n = 0;
	while (*str == '+' || *str == '-')
	{
		if (*str == '-')
			n++;
		str++;
	}
	i = 0;
	if (check_atoi(str, i) == 0)
		return (0);
	else
		return (1);
	if (n % 2 != 0)
		return (0);
	return (1);
}

int	ft_isp(char c)
{
	return (c >= 32 && c < 127);
}
