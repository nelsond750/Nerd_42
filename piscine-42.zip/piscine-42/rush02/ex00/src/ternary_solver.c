/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ternary_solver.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/03 18:55:58 by psimao            #+#    #+#             */
/*   Updated: 2024/11/03 18:56:02 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/ft_rush.h"

char	*tern1(char c1, char c2)
{
	if (c1 != c2)
		return (DDELIM);
	else
		return ("");
}

char	*tern2(int n1, int n2)
{
	if (n1 == n2)
		return (DDELIM);
	else
		return ("");
}

void	tern3(int last)
{
	if (last)
		ft_putstr(HDELIM);
	else
		ft_putstr(DELIM);
}
