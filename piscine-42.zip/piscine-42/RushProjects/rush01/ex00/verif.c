/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   verif.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/27 18:02:29 by psimao            #+#    #+#             */
/*   Updated: 2024/10/27 18:10:43 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

int	check(int *row, int val)
{
	int	stock;
	int	cur;
	int	num;

	cur = 1;
	stock = row[0];
	num = 1;
	while (num < 4)
	{
		if (row[num] > stock)
		{
			cur++;
			stock = row[num];
		}
		num++;
	}
	return (cur == val && el_in_tab(row) == 0);
}

/*
 * Inverte a linha `row`, verifica a visibilidade e a retorna ao normal.
 */
int	check_reverse(int *row, int val)
{
	int	ret;

	ft_rev_int_tab(row, 4);
	ret = check(row, val);
	ft_rev_int_tab(row, 4);
	return (ret);
}

/*
 * Verifica a visibilidade para todas as linhas.
 */
int	verif_rows(int tab[4][4], int *val)
{
	if (!check(tab[0], val[8]) || !check_reverse(tab[0], val[12])
		|| !check(tab[1], val[9]) || !check_reverse(tab[1], val[13])
		|| !check(tab[2], val[10]) || !check_reverse(tab[2], val[14])
		|| !check(tab[3], val[11]) || !check_reverse(tab[3], val[15]))
		return (0);
	return (1);
}

/*
 * Verifica a visibilidade para todas as colunas.
 */
int	verif_cols(int tab[4][4], int *val)
{
	int	test_tab[4];
	int	i;

	i = 0;
	while (i < 4)
	{
		get_cols(test_tab, tab, i);
		if (!check(test_tab, val[i])
			|| !check_reverse(test_tab, val[i + 4]))
			return (0);
		i++;
	}
	return (1);
}
/*
 * Verifica todas as restrições de visibilidade para linhas e colunas.
 */

int	verif(int tab[4][4], int *val)
{
	return (verif_rows(tab, val) && verif_cols(tab, val));
}
