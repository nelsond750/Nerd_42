/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/27 18:01:23 by psimao            #+#    #+#             */
/*   Updated: 2024/10/27 18:25:06 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH01_H
# define RUSH01_H

# include <unistd.h>

void	ft_rev_int_tab(int *tab, int size);
int		el_in_tab(int *row);
void	get_cols(int col_tab[4], int tab[4][4], int col_num);
void	lines_to_array(int checktab[4][4], int permut[24][4], int linesnum[4]);
void	print_solution(int tab[4][4]);

int		check(int *row, int val);
int		check_reverse(int *row, int val);
int		verif_rows(int tab[4][4], int *val);
int		verif_cols(int tab[4][4], int *val);
int		verif(int tab[4][4], int *val);

void	swap(int *x, int *y);
void	add_permut(int v[4], int permut[24][4], int *cur);
void	heappermute(int c[], int n, int permut[24][4], int *cur);
void	copy_array(int told[24][4], int tnew[24][4]);
void	get_permut(int permut[24][4]);

// Funções de `resolve.c`
void	resolve(int val[16]);

#endif
