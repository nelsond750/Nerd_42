/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/27 18:01:50 by psimao            #+#    #+#             */
/*   Updated: 2024/10/27 18:04:42 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

/*
 * Verifica se o caractere em `argv[1]` na posição `cur` está correto,
 * e se for um número, o adiciona ao array `val`.
 */
int	process_char(int cur, char **argv, int val[16])
{
	if (cur > 31)
	{
		write(1, "Error\n", 6);
		return (1);
	}
	if (cur % 2 == 0)
	{
		if (argv[1][cur] >= '1' && argv[1][cur] <= '4')
			val[cur / 2] = argv[1][cur] - '0';
		else
		{
			write(1, "Error\n", 6);
			return (1);
		}
	}
	else if (argv[1][cur] != ' ')
	{
		write(1, "Error\n", 6);
		return (1);
	}
	return (0);
}

/*
 * Função principal: converte a entrada em um array de valores e chama resolve.
 */
int	main(int argc, char **argv)
{
	int	val[16];
	int	cur;

	if (argc != 2)
	{
		write(1, "Error\n", 6);
		return (1);
	}
	cur = -1;
	while (argv[1][++cur] != 0)
	{
		if (process_char(cur, argv, val) == 1)
			return (1);
	}
	resolve(val);
}
