/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   resolve.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/27 18:44:46 by psimao            #+#    #+#             */
/*   Updated: 2024/10/27 19:26:20 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

int	loop2(int linesnum[4], int checktab[4][4], int permut[24][4], int val[16])
{
	while (linesnum[3] < 24)
	{
		lines_to_array(checktab, permut, linesnum);
		if (verif(checktab, val) == 1)
		{
			print_solution(checktab);
			return (1);
		}
		linesnum[3]++;
	}
	return (0);
}

int	loop(int linesnum[4], int checktab[4][4], int permut[24][4], int val[16])
{
	while (linesnum[0] < 24)
	{
		linesnum[1] = 0;
		while (linesnum[1] < 24)
		{
			linesnum[2] = 0;
			while (linesnum[2] < 24)
			{
				linesnum[3] = 0;
				if (loop2(linesnum, checktab, permut, val) == 1)
					return (1);
				linesnum[2]++;
			}
			linesnum[1]++;
		}
		linesnum[0]++;
	}
	return (0);
}

void	resolve(int val[16])
{
	int	permut[24][4];
	int	checktab[4][4];
	int	linesnum[4];
	int	i;

	get_permut(permut);
	i = 0;
	while (i < 4)
	{
		linesnum[i] = 0;
		i++;
	}
	if (loop(linesnum, checktab, permut, val) == 0)
		write(1, "Error\n", 6);
}
