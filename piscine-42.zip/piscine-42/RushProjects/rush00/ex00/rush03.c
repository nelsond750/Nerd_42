/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: psimao <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/20 19:17:50 by psimao            #+#    #+#             */
/*   Updated: 2024/10/20 20:20:32 by psimao           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	print_first_or_last_line(int x)
{
	int	coluna;

	coluna = 1;
	while (coluna <= x)
	{
		if (coluna == 1)
			ft_putchar('A');
		else if (coluna == x)
			ft_putchar('C');
		else
			ft_putchar('B');
		coluna++;
	}
	ft_putchar('\n');
}

void	print_middle_lines(int x)
{
	int	coluna;

	coluna = 1;
	while (coluna <= x)
	{
		if (coluna == 1 || coluna == x)
			ft_putchar('B');
		else
			ft_putchar(' ');
		coluna++;
	}
	ft_putchar('\n');
}

void	rush03(int x, int y)
{
	int	linha;

	if (x <= 0 || y <= 0)
		return ;
	linha = 1;
	while (linha <= y)
	{
		if (linha == 1 || linha == y)
			print_first_or_last_line(x);
		else
			print_middle_lines(x);
		linha++;
	}
}
