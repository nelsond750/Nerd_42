#ifndef FT_STOCK_STR
# define FT_STOCK_STR

typedef struct s_stock_str
{
	int size;
	char *str;
	char *copy;
}								t_stock_str;

#endif
