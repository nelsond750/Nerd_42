/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ex05.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima-ce <llima-ce@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/18 14:46:48 by llima-ce          #+#    #+#             */
/*   Updated: 2021/07/22 00:44:44 by llima-ce         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void ft_putstr(char *str);

int main(void){
	char *str;
	
	str = "./r1xrolkd4dt26pp7n0y7s9p0\n";
	ft_putstr(str);
	return(0);
}
